namespace BOL;
public class Login
{
 public Login(){
    this.UserName="";
    this.Pass="";
 }
public string UserName{get; set;}
public string Pass{get; set;}

}