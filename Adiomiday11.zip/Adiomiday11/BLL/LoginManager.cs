﻿namespace BLL;
using BOL;
using DAL;

public class LoginManager

{
  public  List<Login>  GetLogin()
  {

    DBmanager2 db=new DBmanager2();
    List<Login> ls= db.Getalldata();
    return ls;

   

  }

}
