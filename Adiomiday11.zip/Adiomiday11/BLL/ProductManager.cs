﻿namespace BLL;
using BOL;
using DAL;

public class ProductManager

{
  // public  List<Product>  GetProduct()
  // {

  //   DBmanager2 db=new DBmanager2();
  //   // List<Product> ls= db.Getalldata();
  //   return ls;

   

  // }

}
