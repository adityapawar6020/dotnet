using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;

using BOL;
using BLL;

namespace day11.Controllers;

public class ProductController : Controller
{
    private readonly ILogger< ProductController> _logger;

    public ProductController(ILogger<ProductController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }
    // public IActionResult ShowProducts()
    // {
    //     ProductManager obj=new ProductManager();
    //     List<Product> pl=obj.GetProduct();
    //     ViewData["key"]=pl;
    //     return View();
    // }

  
}
