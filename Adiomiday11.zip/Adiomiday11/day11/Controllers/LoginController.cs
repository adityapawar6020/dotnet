using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using BOL;
using BLL;
namespace day11.Controllers;

public class LoginController : Controller
{
    private readonly ILogger<LoginController> _logger;

    public LoginController(ILogger<LoginController> logger)
    {
        _logger = logger;
    }
    [HttpGet]
    public IActionResult Login1()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Login1(string user,string pass)
    { 
      LoginManager l=new LoginManager();
       List<Login> lg=l.GetLogin();
       foreach(Login l1 in lg){
         if(l1.Pass==pass &&l1.UserName==user){
            Console.WriteLine("areh");
            return this.RedirectToAction("welcome","Login");
         }
         
       }
      
        return View();
    }
      public IActionResult welcome()
    {
        return View();
    }
   
}
