namespace DAL;
using BOL;
using MySql.Data.MySqlClient;


public class DBmanager2{

    public List<Login> Getalldata()
    {
       List<Login> pl=new List<Login>();

       MySqlConnection conn=new MySqlConnection();
       conn.ConnectionString="server=192.168.10.150;port=3306;user=dac10;password=welcome;database=dac10";
       string query="Select * from login";

       MySqlCommand cmd=new MySqlCommand(query,conn);

       conn.Open();

       try
       {MySqlDataReader x=cmd.ExecuteReader();
        // MySqlDataReader x=new MySqlDataReader();
         while(x.Read())
         {

          string user=x["username"].ToString();
          string pass= x["password"].ToString();
          Login p=new Login{UserName=user,Pass=pass};
          pl.Add(p);

         } 
         x.Close();

       }
       catch(Exception e)
       {
         
        Console.WriteLine(e.Message);


       } 

      finally
     {
      conn.Close();
     }



      return pl;

    }















}