﻿namespace DAL;
using BOL;
using MySql.Data.MySqlClient;

public class DBmanager
{

    public  List<Product> GetAllProduct()
    {
     List<Product> li= new List<Product>();

     MySqlConnection conn=new MySqlConnection();
     conn.ConnectionString="server=192.168.10.150;port=3306;user=dac10;password=welcome;database=dac10";
     string query="select * from products";

     MySqlCommand cmd=new MySqlCommand(query,conn);
     
           conn.Open();
     try{

     MySqlDataReader reader=cmd.ExecuteReader();
     while(reader.Read()){

      int i=int.Parse(reader["Product_id"].ToString());
      string nm=reader["Product_name"].ToString();
      Product p=new Product{Id=i,Name=nm};
      li.Add(p);
     }

      reader.Close();
     }

      catch(Exception e){
                  Console.WriteLine(e.Message);
      }

 

    finally{

      conn.Close();
    }




    //  to do hard code
    //  products.Add(new Product{Id=1,Name="Gooday"});
    //  products.Add(new Product{Id=2,Name="ParleG"});
    //  products.Add(new Product{Id=3,Name="Hidensik"});

      return li ;

    }

}
