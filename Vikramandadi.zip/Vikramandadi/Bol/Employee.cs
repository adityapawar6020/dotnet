﻿namespace Bol;




public class Employee {


public string Name{get; set;}

public int Id{get;set;}

// public Employee(string Name,int Id)
// {

//  this.Name=Name;
//  this.Id=Id;

// }


}





