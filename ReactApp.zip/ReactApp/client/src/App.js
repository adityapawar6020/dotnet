
import './App.css';
import axios from "axios";


function App() {


  var res = axios.get("http://localhost:5130/weatherforecast");
  // console.log(res);


  return (
    <div className="App">
      <h1>App</h1>
      <h1> {res} </h1>
    </div>
  );
}

export default App;
